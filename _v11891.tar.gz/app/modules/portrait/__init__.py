# StuLink v1.18.9.1 2026-10-09
# 学生画像模块：综合画像 · 评语管理 · 事件记录
# Copyright (c) 2026 zkxxzf. Apache License 2.0
from app.modules.portrait.routes.portrait import bp  # noqa: F401
