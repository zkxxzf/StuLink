"""模块蓝图注册入口"""
def register_blueprints(app):
    # 认证模块（共享）
    from app.modules.auth.routes import bp as auth_bp
    app.register_blueprint(auth_bp)

    # 欢迎页（/）
    from app.modules.welcome.routes import bp as welcome_bp
    app.register_blueprint(welcome_bp)

    # 宿舍管理模块
    from app.modules.dormitory.routes.dashboard import bp as dashboard_bp
    from app.modules.dormitory.routes.rooms import bp as rooms_bp
    from app.modules.dormitory.routes.assignments import bp as assignments_bp
    from app.modules.dormitory.routes.statistics import bp as statistics_bp
    app.register_blueprint(dashboard_bp)
    app.register_blueprint(rooms_bp)
    app.register_blueprint(assignments_bp)
    app.register_blueprint(statistics_bp)

    # 系统管理模块
    from app.modules.system.routes.dashboard import bp as system_dashboard_bp
    from app.modules.system.routes.students import bp as students_bp
    from app.modules.system.routes.users import bp as users_bp
    from app.modules.system.routes.dictionary import bp as dictionary_bp
    from app.modules.system.routes.class_profile import bp as class_profile_bp
    from app.modules.system.routes.perm_groups import bp as perm_groups_bp
    from app.modules.system.routes.grade_mgmt import bp as grade_mgmt_bp
    from app.modules.system.routes.operation_logs import bp as operation_logs_bp
    app.register_blueprint(system_dashboard_bp)
    app.register_blueprint(students_bp)
    app.register_blueprint(users_bp)
    app.register_blueprint(dictionary_bp)
    app.register_blueprint(class_profile_bp)
    app.register_blueprint(perm_groups_bp)
    app.register_blueprint(grade_mgmt_bp)
    app.register_blueprint(operation_logs_bp)

    # 占位模块
    from app.modules.points.routes import bp as points_bp
    from app.modules.grades import bp as grades_bp
    app.register_blueprint(points_bp)
    app.register_blueprint(grades_bp)

    # 教务模块与教师工作台（v1.14.0）
    from app.modules.academic import bp as academic_bp
    from app.modules.workbench.routes import bp as workbench_bp
    from app.modules.workbench.routes.overview import bp as overview_bp
    from app.modules.workbench.routes.attendance import bp as attendance_bp
    from app.modules.workbench.routes.records import bp as records_bp
    app.register_blueprint(academic_bp)
    app.register_blueprint(workbench_bp)
    app.register_blueprint(overview_bp)
    app.register_blueprint(attendance_bp)
    app.register_blueprint(records_bp)

    # 学生画像模块（v1.15.0）
    from app.modules.portrait import bp as portrait_bp
    app.register_blueprint(portrait_bp)

    # 通知公告模块（v1.9.3，独立模块）
    from app.modules.notifications.routes import bp as notifications_bp
    app.register_blueprint(notifications_bp)

# StuLink v1.7.0 2026-08-02
# Copyright (c) 2026 zkxxzf. Apache License 2.0


