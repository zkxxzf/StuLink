# StuLink v1.7.0 2026-08-02
# Copyright (c) 2026 zkxxzf. Apache License 2.0
import secrets
from flask import Blueprint, render_template, redirect, url_for, flash, request, send_file
from flask_login import login_required, current_user
from app.extensions import db
from app.models import User, PermissionGroup
from app.forms.user_forms import UserForm
from app.utils.decorators import perm_required
from app.utils.helpers import log_operation
from app.modules.academic.services import teacher_sync
import io

bp = Blueprint('users', __name__, url_prefix='/users')


def _generate_password():
    """生成随机一次性口令（12 位字母数字，保证同时含字母与数字以符合
    app/utils/password_policy.py 的策略）"""
    import string
    alphabet = string.ascii_letters + string.digits
    while True:
        pwd = ''.join(secrets.choice(alphabet) for _ in range(12))
        if any(c.isdigit() for c in pwd) and any(c.isalpha() for c in pwd):
            return pwd


def _store_one_time_password(username, real_name, password):
    """L-7：初始/重置口令不再写进 flash（会进响应 HTML 与签名 cookie），
    改为放进 session 的一次性展示区，在用户列表页显示一次即失效。"""
    from flask import session
    items = session.get('_pwd_once', [])
    items.append({'username': username, 'real_name': real_name,
                  'password': password})
    session['_pwd_once'] = items[-50:]
    session.modified = True


@bp.route('/')
@perm_required('system.users')
def list_users():
    from flask import session
    users = User.query.order_by(User.role, User.username).all()
    # L-7：取出一次性初始口令（显示后立即失效）
    one_time_passwords = session.pop('_pwd_once', []) if users is not None else []
    # v1.14.0：按权限组分组展示（组内按角色/用户名排序），支持分组折叠与搜索
    from collections import OrderedDict
    grouped = OrderedDict()
    for u in users:
        gname = u.permission_group.name if u.permission_group else '未分组'
        grouped.setdefault(gname, []).append(u)
    group_order = {g.name: g.id for g in PermissionGroup.query.all()}
    groups = OrderedDict(
        (g, grouped[g]) for g in sorted(grouped, key=lambda x: (group_order.get(x, 9999), x)))
    return render_template('system/users/list.html', users=users, groups=groups,
                           one_time_passwords=one_time_passwords)


@bp.route('/create', methods=['GET', 'POST'])
@perm_required('system.users')
def create():
    form = UserForm()
    if form.validate_on_submit():
        if User.query.filter_by(username=form.username.data).first():
            flash('用户名已存在', 'danger')
            return render_template('system/users/form.html', form=form, title='新建用户')

        # 校验：班主任最多3人/班，且年级班级必填
        role = form.role.data
        grade = form.grade.data or None
        class_name = form.class_name.data or None

        if role == 'homeroom_teacher':
            if not grade or not class_name:
                flash('班主任必须指定年级和班级', 'danger')
                return render_template('system/users/form.html', form=form, title='新建用户')
            existing_count = User.query.filter_by(
                role='homeroom_teacher', grade=grade, class_name=class_name, is_active=True
            ).count()
            if existing_count >= 3:
                flash(f'{grade}{class_name} 已有 {existing_count} 名班主任，最多设置3名', 'danger')
                return render_template('system/users/form.html', form=form, title='新建用户')

        if role == 'grade_leader' and not grade:
            flash('年级长必须指定管理年级', 'danger')
            return render_template('system/users/form.html', form=form, title='新建用户')

        user = User(
            username=form.username.data,
            real_name=form.real_name.data,
            role=role,
            grade=grade,
            class_name=class_name,
            permission_group_id=form.permission_group_id.data if form.permission_group_id.data else None,
            must_change_pwd=True,
        )
        generated_pwd = form.password.data or _generate_password()
        user.set_password(generated_pwd)
        db.session.add(user)
        db.session.commit()
        # v1.18.9.1：非管理员自动同步创建教师档案（admin 不写入）
        _sync_state, _ = teacher_sync.sync_from_user(user)
        db.session.commit()
        log_operation(current_user, '创建', '用户', user.id, f'{user.real_name} ({user.role_display})')
        # L-7：初始口令不再经 flash 明文回显（会进响应 HTML 与签名 cookie）
        auto_pwd = not form.password.data
        if auto_pwd:
            _store_one_time_password(user.username, user.real_name, generated_pwd)
        flash(f'用户 {user.real_name} 已创建'
              + ('，初始口令已在本页一次性显示（仅此一次，请立即转交本人）' if auto_pwd else ''),
              'success')
        return redirect(url_for('users.list_users'))
    return render_template('system/users/form.html', form=form, title='新建用户')


@bp.route('/<int:id>/edit', methods=['GET', 'POST'])
@perm_required('system.users')
def edit(id):
    user = User.query.get_or_404(id)
    form = UserForm(obj=user)
    if form.validate_on_submit():
        existing = User.query.filter(
            User.username == form.username.data, User.id != user.id).first()
        if existing:
            flash('用户名已存在', 'danger')
            return render_template('system/users/form.html', form=form, title='编辑用户')

        # 校验
        role = form.role.data
        grade = form.grade.data or None
        class_name = form.class_name.data or None

        # v1.9.2 防误操作：管理员账号的角色不可修改
        if user.role == 'admin' and role != 'admin':
            flash('管理员账号的角色不可修改（防止系统失去管理入口）', 'danger')
            return render_template('system/users/form.html', form=form, title='编辑用户')

        if role == 'homeroom_teacher':
            if not grade or not class_name:
                flash('班主任必须指定年级和班级', 'danger')
                return render_template('system/users/form.html', form=form, title='编辑用户')
            existing_count = User.query.filter_by(
                role='homeroom_teacher', grade=grade, class_name=class_name, is_active=True
            ).filter(User.id != user.id).count()
            if existing_count >= 3:
                flash(f'{grade}{class_name} 已有 {existing_count} 名班主任，最多设置3名', 'danger')
                return render_template('system/users/form.html', form=form, title='编辑用户')

        if role == 'grade_leader' and not grade:
            flash('年级长必须指定管理年级', 'danger')
            return render_template('system/users/form.html', form=form, title='编辑用户')

        user.username = form.username.data
        # 姓名锁定：真实姓名与任课安排/成绩归属绑定，一经创建不可修改（成绩模块约定）
        new_name = (form.real_name.data or '').strip()
        if new_name and new_name != user.real_name:
            flash('真实姓名不可修改（与任课安排/成绩归属绑定），已保留原姓名', 'warning')
        user.role = role
        user.grade = grade
        user.class_name = class_name
        user.permission_group_id = form.permission_group_id.data if form.permission_group_id.data else None
        if form.password.data:
            user.set_password(form.password.data)
        db.session.commit()
        # v1.18.9.1：教师角色变更 → 同步到 academic.teachers（admin 自动 skip）
        teacher_sync.sync_from_user(user)
        db.session.commit()
        log_operation(current_user, '更新', '用户', user.id, f'{user.real_name} 信息已更新')
        flash('用户信息已更新', 'success')
        return redirect(url_for('users.list_users'))
    return render_template('system/users/form.html', form=form, title='编辑用户')


@bp.route('/<int:id>/toggle', methods=['POST'])
@perm_required('system.users')
def toggle(id):
    user = User.query.get_or_404(id)
    # v1.9.2 防误操作：管理员账号不可禁用；不能禁用当前登录账号
    if user.role == 'admin' and user.is_active:
        flash('管理员账号不允许禁用（防止系统无法登录）', 'danger')
        return redirect(url_for('users.list_users'))
    if user.id == current_user.id and user.is_active:
        flash('不能禁用当前登录的账号', 'danger')
        return redirect(url_for('users.list_users'))
    user.is_active = not user.is_active
    db.session.commit()
    # v1.18.9.1：启禁变更 → 同步 Teacher.status (active/left)
    teacher_sync.sync_from_user(user)
    db.session.commit()
    status = '启用' if user.is_active else '禁用'
    log_operation(current_user, '更新', '用户', user.id, f'{user.real_name} {status}')
    flash(f'用户 {user.real_name} 已{status}', 'success')
    return redirect(url_for('users.list_users'))


@bp.route('/<int:id>/reset-password', methods=['POST'])
@perm_required('system.users')
def reset_password(id):
    user = User.query.get_or_404(id)
    new_pwd = _generate_password()
    user.set_password(new_pwd)
    user.must_change_pwd = True
    db.session.commit()
    log_operation(current_user, '更新', '用户', user.id, f'{user.real_name} 密码已重置')
    # L-7：重置后的口令一次性展示（此前生成后直接丢弃，管理员无法交付）
    _store_one_time_password(user.username, user.real_name, new_pwd)
    flash(f'{user.real_name} 的密码已重置，新口令已在本页一次性显示（仅此一次）', 'success')
    return redirect(url_for('users.list_users'))


@bp.route('/download-teacher-template')
@perm_required('system.users')
def download_teacher_template():
    """下载教师批量导入模板"""
    import openpyxl
    from openpyxl.styles import Font, Alignment, PatternFill, Border, Side

    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = '教师导入模板'

    headers = ['手机号', '真实姓名', '权限组']
    header_fill = PatternFill(start_color='ED7D31', end_color='ED7D31', fill_type='solid')
    header_font = Font(color='FFFFFF', bold=True, size=11)
    thin_border = Border(left=Side(style='thin'), right=Side(style='thin'),
                         top=Side(style='thin'), bottom=Side(style='thin'))

    for col_idx, header in enumerate(headers, 1):
        cell = ws.cell(row=1, column=col_idx, value=header)
        cell.font = header_font
        cell.fill = header_fill
        cell.alignment = Alignment(horizontal='center')
        cell.border = thin_border

    ws.column_dimensions['A'].width = 16
    ws.column_dimensions['B'].width = 14
    ws.column_dimensions['C'].width = 14

    # example row
    ws.append(['13800138000', '张老师', '管理员'])

    # instruction row
    ws.merge_cells('A4:C4')
    instr = ws.cell(row=4, column=1, value='说明：手机号即登录名，初始口令由系统随机生成（导入后在本页一次性展示），首次登录需改密 | 权限组填写系统已有权限组名称 | 第 2 行起填数据，删除本行和示例')
    instr.font = Font(color='FF0000', bold=True, size=10)

    buf = io.BytesIO()
    wb.save(buf)
    buf.seek(0)
    return send_file(buf, as_attachment=True,
                     download_name='教师导入模板.xlsx',
                     mimetype='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')


@bp.route('/import-teachers', methods=['POST'])
@perm_required('system.users')
def import_teachers():
    """批量导入教师：手机号=登录名，初始口令为随机一次性口令（H-1③），
    首次登录强制改密（由 app/__init__.py 的 _force_password_change 兜底）"""
    file = request.files.get('file')
    # L-8：统一上传校验（白名单 + 危险类型 + magic），不再只看扩展名
    from app.utils.upload_guard import validate_upload
    if not file:
        flash('请上传 .xlsx 格式的Excel文件', 'danger')
        return redirect(url_for('users.list_users'))
    ok, msg = validate_upload(file.filename, allowed_exts=['xlsx', 'xls'],
                              stream=file.stream)
    if not ok:
        flash(msg, 'danger')
        return redirect(url_for('users.list_users'))

    try:
        import openpyxl.worksheet.datavalidation as dv
        _orig_init = dv.DataValidation.__init__
        def _patched_init(self, *a, **kw):
            kw.pop('id', None)
            _orig_init(self, *a, **kw)
        dv.DataValidation.__init__ = _patched_init

        import openpyxl
        wb = openpyxl.load_workbook(file, data_only=True)
        ws = wb.active

        header_map = {}
        for col in range(1, ws.max_column + 1):
            val = ws.cell(row=1, column=col).value
            if val:
                header_map[str(val).strip()] = col

        phone_col = header_map.get('手机号')
        name_col = header_map.get('真实姓名')
        group_col = header_map.get('权限组')

        if not phone_col or not name_col or not group_col:
            flash('Excel缺少必填列：手机号、真实姓名、权限组', 'danger')
            return redirect(url_for('users.list_users'))

        # load existing phones and permission groups
        existing_phones = set(r[0] for r in db.session.query(User.username).all() if r[0])
        pg_map = {pg.name: pg for pg in PermissionGroup.query.all()}

        created = 0
        errors = []
        _new_users = []                          # v1.18.9.1：导入后同步至 teachers

        for row_idx in range(2, ws.max_row + 1):
            phone = str(ws.cell(row=row_idx, column=phone_col).value or '').strip()
            name = str(ws.cell(row=row_idx, column=name_col).value or '').strip()
            group_name = str(ws.cell(row=row_idx, column=group_col).value or '').strip()

            if not phone or not name or not group_name:
                continue

            if phone in existing_phones:
                errors.append(f'第{row_idx}行（{name}）：手机号{phone}已存在')
                continue

            pg = pg_map.get(group_name)
            if not pg:
                errors.append(f'第{row_idx}行（{name}）：权限组"{group_name}"不存在')
                continue

            user = User(username=phone, real_name=name, role='teacher',
                        permission_group_id=pg.id,
                        must_change_pwd=True, is_active=True)
            # H-1③：不再用手机号当口令（半公开信息 = 批量可登录），改随机一次性口令
            one_time_pwd = _generate_password()
            user.set_password(one_time_pwd)
            db.session.add(user)
            db.session.flush()
            _store_one_time_password(phone, name, one_time_pwd)
            _new_users.append(user)
            existing_phones.add(phone)
            created += 1

        db.session.commit()
        # v1.18.9.1：批量导入后同步到 academic.teachers
        for u in _new_users:
            teacher_sync.sync_from_user(u)
        db.session.commit()

        if created:
            log_operation(current_user, '导入', '教师', None, f'批量导入 {created} 名教师')
        msg = f'成功导入 {created} 名教师，初始口令已在本页一次性显示（仅此一次）'
        if errors:
            msg += f'，{len(errors)} 条失败：' + '；'.join(errors[:20])
            if len(errors) > 20:
                msg += f'...还有{len(errors)-20}条'
            flash(msg, 'warning')
        else:
            flash(msg, 'success')

    except Exception as e:
        db.session.rollback()
        flash(f'导入失败：{str(e)}', 'danger')

    return redirect(url_for('users.list_users'))


