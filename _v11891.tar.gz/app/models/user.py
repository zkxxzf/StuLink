# StuLink v1.7.0 2026-08-02
# Copyright (c) 2026 zkxxzf. Apache License 2.0
from datetime import datetime
from flask_login import UserMixin
from werkzeug.security import generate_password_hash, check_password_hash
from app.extensions import db, login_manager


class User(UserMixin, db.Model):
    __tablename__ = 'users'

    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(50), unique=True, nullable=False)
    password_hash = db.Column(db.String(256), nullable=False)
    real_name = db.Column(db.String(50), nullable=False)
    role = db.Column(db.String(20), nullable=False)  # 管理员/宿管教师/班主任/普通教师
    grade = db.Column(db.String(10))       # 班主任所管年级
    class_name = db.Column(db.String(10))  # 班主任所管班级
    permission_group_id = db.Column(db.Integer, db.ForeignKey('permission_groups.id'), nullable=True)
    is_active = db.Column(db.Boolean, default=True)
    must_change_pwd = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime, default=datetime.now)
    updated_at = db.Column(db.DateTime, default=datetime.now, onupdate=datetime.now)

    def set_password(self, password):
        self.password_hash = generate_password_hash(password)

    def check_password(self, password):
        return check_password_hash(self.password_hash, password)

    @property
    def role_display(self):
        role_names = {
            'admin': '管理员',
            'dorm_manager': '宿管教师',
            'homeroom_teacher': '班主任',
            'grade_leader': '年级长',
            'school_viewer': '全校组',
            'teacher': '普通教师',
            'staff': '教职人员',
        }
        return role_names.get(self.role, self.role)

    @property
    def display_role(self):
        """显示用身份：优先权限组名（身份可自定义），无组时回落角色名"""
        pg = self.permission_group
        if pg and pg.name:
            return pg.name
        return self.role_display

    def has_role(self, *roles):
        return self.role in roles

    def has_perm(self, perm_key):
        """检查用户是否有指定权限"""
        if self.role == 'admin':
            return True
        pg = self.permission_group
        if pg:
            return pg.has_menu(perm_key)
        return False


@login_manager.user_loader
def load_user(user_id):
    # v1.16.0 性能改造：joinedload 预加载权限组，避免每个请求访问
    # current_user.permission_group 时额外触发一次懒加载查询（每请求省 1 条 SQL）。
    from sqlalchemy.orm import joinedload
    return db.session.query(User).options(
        joinedload(User.permission_group)
    ).filter(User.id == int(user_id)).first()


